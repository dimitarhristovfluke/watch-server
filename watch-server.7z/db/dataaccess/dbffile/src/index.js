"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var dbf_file_1 = require("./dbf-file");
exports.DBFFile = dbf_file_1.DBFFile;
exports.default = dbf_file_1.DBFFile;
//# sourceMappingURL=index.js.map