const config = {
  development: {
    pathToWconnect: "C:\\eMaint\\DEV\\X3_DEV\\wconnect\\"
  },
  testing: {
    pathToWconnect: "D:\\wconnect\\"
  },
  preprod: {
    pathToWconnect: "D:\\wconnect\\"
  },
  production: {
    pathToWconnect: "D:\\wconnect\\"
  }
};

export default config;
